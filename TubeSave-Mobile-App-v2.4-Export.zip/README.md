# TubeSave Mobile Downloader (APK & PWA)

## Package Information
- **Package Name**: com.tubesave.mobile.downloader
- **App Name**: TubeSave
- **Version**: 2.4.0
- **Supported Qualities**: 480p, 720p, 1080p, MP3
- **Storage Target**: Internal Storage (/storage/emulated/0/Download/TubeSave/)

---

## How to Build a Native Android APK

### Method 1: Instant 1-Click APK via PWABuilder (Recommended)
1. Visit https://www.pwabuilder.com
2. Enter your deployed TubeSave app URL.
3. Click **Build APK**.
4. Download the signed `.apk` and `.aab` package directly to your Android device or PC!

### Method 2: Google Bubblewrap CLI (Standard TWA)
```bash
npm install -g @bubblewrap/cli
bubblewrap init --manifest=manifest.webmanifest
bubblewrap build
```
This produces a release-ready `app-release-signed.apk` for direct installation on any Android phone.

### Method 3: Direct Android WebAPK Install
1. Open the app link in Google Chrome or Samsung Internet on your Android phone.
2. Tap the menu (⋮) -> **Install app** or **Add to Home screen**.
3. Android creates a native WebAPK in your app drawer with internal storage access!
